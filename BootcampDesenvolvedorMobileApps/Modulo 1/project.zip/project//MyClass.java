import org.apache.commons.io.FileUtils;
import java.io.*;
import java.util.*;
import lombok.Getter;
import lombok.Setter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.stream.Collectors;


@Getter
@Setter
class Todo implements Comparable<Todo>{
	private Integer userId;
	private Integer id;
	private String title;
	private Boolean completed;
	
    @Override
    public int compareTo(Todo todo){
        return this.title.compareTo(todo.title);
    }
	
}

public class MyClass {
    public static void main(String args[]) {
//      int x=10;
//      Double valor = 5.0;// ou poderia ser 5d
//      double outroValor = 5;
//      
//      Float valorFloat = 5f;
//      
//      System.out.println(Integer.MIN_VALUE);
//      System.out.println(Integer.MAX_VALUE);
//      System.out.println(Double.MIN_VALUE);
//      System.out.println(Double.MAX_VALUE);
//      System.out.println(Float.MIN_VALUE);
//      System.out.println(Float.MAX_VALUE);
    	
    	ArrayList<Todo> todos = new ArrayList();
    	try{
    	    String todoJson = 
    	    FileUtils.readFileToString(new File("./data/todo.txt"));    
    	
    	   Type todoListType = new TypeToken<ArrayList<Todo>>() {}.getType();
    	   Gson gson = new GsonBuilder().create();
    	   
    	   todos = gson.fromJson(todoJson, todoListType);
    	   
    	   System.out.println(todos.size()+"\n");
    	   
    	   for(int i = 0; i < todos.size(); i++){
    	       System.out.println(todos.get(i).getTitle()+"\n");
    	   }
    	   
    	   ArrayList<Todo> todos1 = new ArrayList();
    	   ArrayList<Todo> todos2 = new ArrayList();
    	   
    	   //et porro tempora
    	   todos1 = (ArrayList<Todo>) todos.stream()
    	                .filter(item -> item.getCompleted().equals("et porro tempora"))
    	                .collect(Collectors.toList());
    	                
    	   System.out.println(todos1.size()+"\n");
    	   
    	   for(Todo todo : todos1){
    	       System.out.println(todo.getTitle());
    	   }
    	   
    	   
    	   System.out.println("\n");
    	   
    	   todos2 = (ArrayList<Todo>) todos.stream()
    	                .filter(item -> item.getCompleted().equals(true))
    	                .collect(Collectors.toList());
    	                
    	   System.out.println(todos2.size()+"\nFilter:");
    	   
    	   for(Todo todo : todos2){
    	       System.out.println(todo.getTitle());
    	   }
    	   
    	   System.out.println("\n\nMap:");
    	   todos.stream()
    	        .map(item -> item.getTitle()).forEach(item->System.out.println(item));
    	   
    	   System.out.println("\nSort:");
    	   Collections.sort(todos);
    	   for(Todo todo:todos){
    	       System.out.println(todo.getTitle());
    	   }
    	   
    	}catch(IOException e){
    	    System.out.println(e);    
    	}
    	
    	List<Integer> n = Arrays.asList(10,4,10,1,3);
    	
    	int result = n.stream()
    	               .reduce(0, (subtotal,item) -> subtotal+item );
    	System.out.println("\nReduce:"+result);
    	
    	
    	
    }
}